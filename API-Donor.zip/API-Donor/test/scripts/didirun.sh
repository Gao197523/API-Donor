#!/bin/bash
#
# Useful for ensuring that a script was able to run.

printf "didirun.sh did run\n"
exit 0
