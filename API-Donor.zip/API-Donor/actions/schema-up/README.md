# actions/schema-up

Fetch the latest GraphQL schema changes from github.com. Commit and push the schema change directly to the `master` branch if no further changes are made. Otherwise, open a pull request with the ["schema update" label](https://github.com/atom/github/labels/schema%20update) applied, as long as no such pull request already exists.
